import React from 'react';

const Footer: React.FC = () => {
  const quickLinks = [
    { href: '#about', label: 'אודות' },
    { href: '#services', label: 'שירותים' },
    { href: '#why-me', label: 'למה ירון' },
    { href: '#testimonials', label: 'המלצות' },
    { href: '#contact', label: 'צור קשר' },
  ];

  const services = [
    'הרצאות',
    'סדנאות',
    'ייעוץ ארגוני',
    'ניהול משברים',
  ];

  return (
    <footer style={{ backgroundColor: '#040410', borderTop: '1px solid rgba(255,255,255,0.05)' }}>
      <div className="max-w-7xl mx-auto px-4 md:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-10">
          {/* Column 1: Logo + tagline */}
          <div className="md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              <div
                className="w-9 h-9 rounded-xl flex items-center justify-center text-sm font-black text-white"
                style={{ background: 'linear-gradient(135deg, #FF6B35, #FFD60A)' }}
              >
                י״ח
              </div>
              <span className="text-xl font-black" style={{ fontFamily: 'Heebo, sans-serif' }}>
                <span className="gradient-text-orange">ירון</span>
                <span className="text-white"> חנן</span>
              </span>
            </div>
            <p className="text-sm leading-relaxed mb-6" style={{ color: '#4A5568' }}>
              מומחה לניהול סיכונים ומנהיגות בזמן חירום.
              מסייע לארגונים ומנהלים להתמודד עם כל אתגר.
            </p>
            {/* Social Icons */}
            <div className="flex gap-3">
              <a
                href="#"
                className="w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-200"
                style={{ backgroundColor: 'rgba(255,107,53,0.1)', color: '#FF6B35' }}
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'rgba(255,107,53,0.25)')}
                onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'rgba(255,107,53,0.1)')}
                aria-label="LinkedIn"
              >
                <svg width="16" height="16" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433a2.062 2.062 0 01-2.063-2.065 2.064 2.064 0 112.063 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                </svg>
              </a>
              <a
                href="#"
                className="w-9 h-9 rounded-xl flex items-center justify-center transition-all duration-200"
                style={{ backgroundColor: 'rgba(255,107,53,0.1)', color: '#FF6B35' }}
                onMouseEnter={(e) => (e.currentTarget.style.backgroundColor = 'rgba(255,107,53,0.25)')}
                onMouseLeave={(e) => (e.currentTarget.style.backgroundColor = 'rgba(255,107,53,0.1)')}
                aria-label="Twitter/X"
              >
                <svg width="15" height="15" fill="currentColor" viewBox="0 0 24 24">
                  <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                </svg>
              </a>
            </div>
          </div>

          {/* Column 2: Quick Links */}
          <div>
            <h4 className="text-sm font-black uppercase tracking-widest mb-5 text-white" style={{ fontFamily: 'Heebo, sans-serif' }}>
              ניווט מהיר
            </h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.href}>
                  <a
                    href={link.href}
                    className="text-sm transition-colors duration-200"
                    style={{ color: '#4A5568' }}
                    onMouseEnter={(e) => (e.currentTarget.style.color = '#FF6B35')}
                    onMouseLeave={(e) => (e.currentTarget.style.color = '#4A5568')}
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Column 3: Services */}
          <div>
            <h4 className="text-sm font-black uppercase tracking-widest mb-5 text-white" style={{ fontFamily: 'Heebo, sans-serif' }}>
              שירותים
            </h4>
            <ul className="space-y-3">
              {services.map((svc) => (
                <li key={svc}>
                  <a
                    href="#services"
                    className="text-sm transition-colors duration-200"
                    style={{ color: '#4A5568' }}
                    onMouseEnter={(e) => (e.currentTarget.style.color = '#FF6B35')}
                    onMouseLeave={(e) => (e.currentTarget.style.color = '#4A5568')}
                  >
                    {svc}
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div
          className="pt-6 flex flex-col md:flex-row items-center justify-between gap-3"
          style={{ borderTop: '1px solid rgba(255,255,255,0.05)' }}
        >
          <p className="text-xs" style={{ color: '#2D3748' }}>
            © {new Date().getFullYear()} ירון חנן. כל הזכויות שמורות.
          </p>
          <p className="text-xs" style={{ color: '#2D3748' }}>
            ניהול סיכונים · מנהיגות בזמן חירום · ייעוץ ארגוני
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
